%reflectivity_calc
function [rho]=reflectivity_calc(ref_data,std_data,ref_temp,std_temp,abs_std,abs_water,abs_waterT,tempcoeff,r,r0)
% This function calculates the absorption coefficients of the optically 
% active constituents in a sample inside an integrating cavity.
% The equations are adopted from R�ttgers et al (2005) Practical test of a 
% point-source integrating cavity absorption meter: the performance of 
% different collector assemblies. Appl. Opt. 44, 5549�5560.
%
% Input parameters:
% ref_data (vector): Reference spectrum
% std_data (vector): Standard spectrum
% ref_temp (scalar): Temperature of the reference measurement
% std_temp (scalar): Temperature of the standard measurement
% abs_std (vector): Absorption coefficient spectrum of the standard used
%                   during the calibration
% abs_water (vector): Absorption coefficient spectrum of pure water
% temp_coeff (vector): Coefficients for correction of the absorption 
%                       coefficients of pure water for temperature effects
% r (scalar): Radius of the cavity
% r0 (scalar): Radius of the cavity minus radius of the point light source
%
% Output parameter (data format):
% rho (vector): Reflectivity spectrum inside the cavity
%
% Jochen Wollschl�ger
% Institute for Chemistry and Biology of the Marine Environment
% University of Oldenburg
% Contact: jochen.wollschlaeger@uol.de
% 
% Changelog:
%
% Version 1.0: Finished 18.01.2019
%--------------------------------------------------------------------------

%Calculating the absorption of the used solutions 
%(including temperature correction)
Abs_Ref=abs_water+((ref_temp-abs_waterT).*tempcoeff);
Abs_Std=abs_std+abs_water+((std_temp-abs_waterT).*tempcoeff);

%Calculating_transmission
Trans=std_data./ref_data;
 
%Calculating reflectivity (rho)
PsaAr=(1-exp(-2*Abs_Std*r).*(2*Abs_Std*r+1))./(2*Abs_Std.^2*r^2);
PsaBr=(1-exp(-2*Abs_Ref*r).*(2*Abs_Ref*r+1))./(2*Abs_Ref.^2*r^2);
aAr0=Abs_Std*r0;  
aBr0=Abs_Ref*r0;

rho=(Trans.*exp(-aBr0).*PsaBr-exp(-aAr0).*PsaAr)./...
    ((Trans.*exp(-aBr0).*PsaAr.*PsaBr)-(exp(-aAr0).*PsaBr.*PsaAr));

end