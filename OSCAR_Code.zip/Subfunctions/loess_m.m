%loess
function yi=loess_m(xr,yr,xi,alpha)
% loess (low S)-type of interpolation
% B. Efron; An Introduction to the bootstrap; ISBN 0-412-04231-2; p.77
% 
% Input:
% xr (vector): x values of the original vector
% yr (vector): y values of the original vector
% xi (vector): New x values, where the interpolation is to be calculated
% alpha (scalar): Relative amount of points to be used in local smoothing
%                 (ranging from 0-1)
% 
% Output:
% yi (vector): Interpolated data
% 
% Original code provided by R�diger R�ttgers and Helmut Schiller
% Institute for Coastal Research
% Helmholtz Zentrum Geesthacht.
%
% Modified by Jochen Wollschl�ger
% Institute for Chemistry and Biology of the Marine Environment
% University of Oldenburg
% Contact: jochen.wollschlaeger@uol.de
%
% yr can now also be a matrix (data organized in rows). Allows multiple 
% interpolations at once.
% 
% Changelog:
%
% Version 1.0: Finished 18.01.2019
%--------------------------------------------------------------------------

if size(xr,2) ~= size(yr,2) 
    fprintf('loess_m expects equal lengths for first two input variables\n');
    return
end
if (alpha <= 0.) || (alpha >= 1.) 
    fprintf('loess_m expects alpha in (0,1) but finds alpha=%f\n',alpha);
    return
end

np=round(alpha*length(xr));
[~,h]=sort(xr);
x=xr(h);
y=yr(:,h);
yi=zeros(size(yr,1),length(xi));
for i=1:length(xi)
    [~,h]=sort(abs(x-xi(i)));
    h=h(1:np);
    xt=x(h);
    yt=y(:,h);
    u=abs(xt-xi(i));
    u=u/max(u);
    w=(1.-u.^3).^3;
    [a,b]=fitw_m(xt,yt,w);
    yi(:,i)=a+b.*xi(i);
end
end