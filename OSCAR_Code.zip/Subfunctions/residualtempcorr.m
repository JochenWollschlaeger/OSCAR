%residualtempcorr
function [Spectrum_corr,Delta_Temp]=residualtempcorr(Wavelengths,Spectrum,TempCoeffs,NIR_Range,DeltaMax)
% This functions corrects an absorption coefficient spectrum for residual
% temperatur differences between reference and sample.
% It is based on the approach published in Slade et al. (2010) "Underway and
% moored methods for improving accuracy in measurement of spectral particulate 
% absorption and attenuation. J. Atmos. Ocean. Technol. 27, 1733�1746".
% The difference in this approach is that here, only the temperature correction
% is performed, not a correction for particle scattering. Furthermore, it is
% based on the total absorption instead of the particulate absorption, as the
% difference between the two is negligible in the NIR. Finaslly, the minimum
% of the defined NIR region is automatically chosen as reference wavelength
% instead of a fixed wavelength.
% 
% Input:
%   Wavelengths (vector, 1-by-n) : Wavelengths corresponding to the absorption 
%                                  coefficient spectrum.
%   Spectrum (vector, 1-by-n)    : Absorption coefficient spectrum.
%   TempCoeffs (vector, 1-by-n)  : Temperature coefficients of pure water 
%                                  absorption for the corresponding wavelengths
%                                  (e.g. from Pegau et al. 1997).
%   NIR_Range (vector, 1-by-n)   : Wavelength range in the NIR that constitutes
%                                  the basis for the temperature correction 
%                                  (e.g. [710:720]).
%   DeltaMax (scalar)            : Range limit for the temperatur correction 
%                                  (in �C; e.g. 2 means a correction of max.
%                                   +/- 2 degrees).
%
% Output:
%   Spectrum_corr (vector, 1-by-n): Corrected absorption coefficient spectrum
%   Delta_Temp (scalar)           : Corrected temperature difference
%
%**************************************************************************
% 
% Jochen Wollschl�ger
% Institute for Chemistry and Biology of the Marine Environment
% University of Oldenburg
% Contact: jochen.wollschlaeger@uol.de
%
% 23.08.2019
% 
% Changelog:
%
% 29.08.2019: Changed the function searching for the minimum difference
%             from fminsearch.m to fminbnd.m. fminbnd allows the setting of
%             upper and lower bounds by the user (e.g. avoidig unreasonable
%             strong corrections)
%
%--------------------------------------------------------------------------

DeltaMax=abs(DeltaMax);
NIR_Spectrum=Spectrum(ismember(Wavelengths,NIR_Range));
NIR_TempCoeffs=TempCoeffs(ismember(Wavelengths,NIR_Range));
Delta_Temp=fminbnd(@(Delta_Temp) MinimizeDiff(NIR_Spectrum,NIR_TempCoeffs,Delta_Temp),DeltaMax.*-1,DeltaMax);
Spectrum_corr=Spectrum-(Delta_Temp.*TempCoeffs);

    %Function to be minimized in order to get a flat spectrum in the NIR
    function [Difference]=MinimizeDiff(NIR_Spectrum,NIR_TempCoeffs,Delta_Temp)
    NIR_Spectrum_corr=NIR_Spectrum-(Delta_Temp.*NIR_TempCoeffs);
    Difference=sum(NIR_Spectrum_corr-repmat(min(NIR_Spectrum_corr),1,size(NIR_Spectrum_corr,2)));
    end
end