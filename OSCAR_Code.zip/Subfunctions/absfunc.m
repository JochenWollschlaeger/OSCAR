%absfunc
function diff=absfunc(a,T,rho,Psaref,r0,aref,r)
% This function is used in the iterational determination of the absorption
% coefficient of the absorption_calc.m function.
% It calculates the difference between the measured and estimated
% transmission. The latter is a function of the absorption.
% The calculations are based on equations given in 
% R�ttgers et al (2005) Practical test of a point-source integrating cavity
% absorption meter: the performance of different collector assemblies. 
% Appl. Opt. 44, 5549�5560.
%
% Input:
% a (scalar): Absorption coefficient at a specific wavelength
% T (scalar): Transmission at a specific wavelength
% rho (scalar): Reflectivity of the cavity at a specific wavelength
% Psaref (scalar): Probability of a photon reaching the cavity wall
% r0 (scalar): Radius of the cavity minus radius of the point light source
% aref (scalar): Absorption coefficient at a specific wavelength
% r (scalar): Radius of the cavity
%
% Output:
% diff (scalar): Squared difference between measured and estimated
%                transmission.
%
% Original code provided by R�diger R�ttgers
% Institute for Coastal Research
% Helmholtz Zentrum Geesthacht.
%
% Modified by Jochen Wollschl�ger
% Institute for Chemistry and Biology of the Marine Environment
% University of Oldenburg
% Contact: jochen.wollschlaeger@uol.de
%
% Changelog:
%
% Version 1.0: Finished 18.01.2019
%--------------------------------------------------------------------------

Psa=(1-exp(-2*a*r)*(2*a*r+1))/(2*a^2*r^2);

tguess=exp(-r0*(a-aref))*(1-rho*Psaref)/(1-rho*Psa)*Psa/Psaref;

diff=(T-tguess)*(T-tguess);
end