%absorption_calc
function [abs_coeff]=absorption_calc(ref_data,sample_data,rho,abs_water,abs_waterT,ref_temp,sample_temp,tempcoeff,salinity,saltcoeff,r,r0)
% This function calculates the absorption coefficients of the optically 
% active constituents in a sample inside an integrating cavity.
% The equations are adopted from R�ttgers et al (2005) Practical test of a 
% point-source integrating cavity absorption meter: the performance of 
% different collector assemblies. Appl. Opt. 44, 5549�5560.
%
% Input:
% ref_data (vector): Reference spectrum
% sample_data (vector): Sample spectrum
% rho (vector): Reflectivity spectrum inside the cavity
% abs_water (vector): Absorption coefficient spectrum of pure water
% ref_temp (scalar): Temperature of the reference measurement
% sample_temp (scalar): Temperature of the sample measurement
% tempcoeff (vector): Coefficients for correction of the pure water 
%                     absorption for the effects of temperature
% salinity (scalar): Salinity of the sample
% saltcoeff (vector): Coefficients for correction of the pure water 
%                     absorption for the effects of salinity
% r (scalar): Radius of the cavity
% r0 (scalar): Radius of the cavity minus radius of the point light source
%
% Output:
% abs_coeff (vector): Wavelength-specific absorption coefficients
%
% Jochen Wollschl�ger
% Institute for Chemistry and Biology of the Marine Environment
% University of Oldenburg
% Contact: jochen.wollschlaeger@uol.de
% 
% Changelog:
%
% Version 1.0: Finished (18.01.2019)
% Version 1.1: Automatical smoothing and quality control removed for
%              simplicity. These steps can (if necessary) better 
%              implemented separately (20.09.2019)
%--------------------------------------------------------------------------

%Calculation of transmission
trans=sample_data./ref_data;
trans=loess_m(1:length(trans),trans,1:length(trans),0.05);

%Calculating water absorption of the reference (correction for temperature)
abs_wass_ref=abs_water+((ref_temp-abs_waterT)*tempcoeff);

%Calculating water absorption of the sample (correction for temperature and
%salinity)
abs_wass_sample=abs_water+((sample_temp-abs_waterT)*tempcoeff+salinity*saltcoeff); 

%Calculating absorption of sample
abr=r*abs_wass_ref; 
Psab=(1-exp(-2*abr).*(2*abr+1))./(2*abr.^2);
abs_coeff=zeros(size(trans));
for i=1:size(trans,2) %Calculation of absorption per wavelength
        [x,~,~,~]=fminsearch(@absfunc,abs_wass_sample(i),[],trans(i),...
                             rho(i),Psab(i),r0,abs_wass_ref(i),r);
        abs_coeff(i)=x-abs_wass_sample(i);
end
end