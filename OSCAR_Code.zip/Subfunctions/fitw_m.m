%fitw
function [a,b]=fitw_m(xt,yt,w)
% Subfunction for loess_m.m
%
% Original code provided by R�diger R�ttgers and Helmut Schiller
% Institute for Coastal Research
% Helmholtz Zentrum Geesthacht.
%
% Modified by Jochen Wollschl�ger
% Institute for Chemistry and Biology of the Marine Environment
% University of Oldenburg
% Contact: jochen.wollschlaeger@uol.de
%
% yt can now also be a matrix (data organized in rows). Allows to fit 
% multiple values at once.
% 
% Changelog:
%
% Version 1.0: Finished 18.01.2019
%--------------------------------------------------------------------------

xt=repmat(xt,size(yt,1),1);
w=repmat(w,size(yt,1),1);

w2 = w.^2;
S = sum(w2,2);
Sx = sum(xt.*w2,2);
Sy = sum(yt.*w2,2);
Sxx = sum(xt.^2.*w2,2);
Sxy = sum(xt.*yt.*w2,2);

delta = S.*Sxx-Sx.^2;
a = (Sxx.*Sy-Sx.*Sxy)./delta;
b = (S.*Sxy-Sx.*Sy)./delta;
end