% Script for calculating the reflectivity of an OSCAR integrating cavity
% (TriOS GmbH, Germany) 
%
% The script requires the output of the "A_Import_OSCAR.m" script,
% specifically the "CalibrationData.txt" and the "Constants.txt".
%
% The result of the script is a textfile ("Reflectivity.txt") that contains
% the reflectivity spectra as well as the begin and end of each calibration.
%
% The reflectivity spectra should be checked for their reasonability, and
% incorrect calibrations can be deleted before calculating the absorption
% coefficients of the sample measurements. Do not change timestamp formats
% or length of individual vectors. This will cause problems for subsequent
% scripts.
%
% Furthermore, the script performs also an estimation of the uncertainty
% associated with the determination of the reflectivity. This uncertainty
% results from the error associated with the absorption coefficient 
% determination of the standard used for calibration, as well as from the 
% uncertainties measuring the calibration liquids with the OSCAR
% (represented by the doubled standard deviation of the mean value
% constituting a certain calibration reference or calibration standard
% measurement). The error margins are calculated assuming that the errors
% working together towards a higher or lower reflectivity, respectively.
% 
%
% Jochen Wollschl�ger
% Institute for Chemistry and Biology of the Marine Environment
% University of Oldenburg
% Contact: jochen.wollschlaeger@uol.de
% 
% Changelog:
%
% Version 1.0: Finished (07.06.2019)
% Version 1.1: Implementation of the uncertainty estimation of the
%              reflectivity (17.09.2019)
%
% License information:
% Copyright (c) [2019] [Jochen Wollschl�ger]
% Permission is hereby granted, free of charge, to any person obtaining a
% copy of this software and associated documentation files (the "Software"),
% to deal in the Software without restriction, including without limitation
% the rights to use, copy, modify, merge, publish, distribute, sublicense,
% and/or sell copies of the Software, and to permit persons to whom the 
% Software is furnished to do so, subject to the following conditions:
% 
% The above copyright notice and this permission notice shall be included 
% in all copies or substantial portions of the Software.
% 
% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS 
% OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
% MERCHANTABILITY,FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
% IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY 
% CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT
% OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR 
% THE USE OR OTHER DEALINGS IN THE SOFTWARE.
%--------------------------------------------------------------------------

clc
clear
BasicPath=pwd;

%% Parameters

%Path of the folder that contains the output of the previously executed 
%script
InputDataFolder=[BasicPath,'\Results'];

%Name of the folder that will contain the output files
%If not existing, the folder will be created
ResultsFolder=[BasicPath,'\Results'];

%Path of the folder that contains the custom-build functions of the script
FunctionsFolder=[BasicPath,'\Subfunctions'];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%FROM HERE, ONLY MAKE MODIFICATIONS IF YOU KNOW WHAT YOU ARE DOING!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Check the operating system

if ismac
    InputDataFolder=strrep(InputDataFolder,'\','/');
    ResultsFolder=strrep(ResultsFolder,'\','/');
    FunctionsFolder=strrep(FunctionsFolder,'\','/');
elseif isunix
    InputDataFolder=strrep(InputDataFolder,'\','/');
    ResultsFolder=strrep(ResultsFolder,'\','/');
    FunctionsFolder=strrep(FunctionsFolder,'\','/');
elseif ispc
else
    error('Platform not supported')
end

[~,VersionRelease]=version;
if datenum(VersionRelease,'mmmm dd, yyyy')<datenum('January 5, 2019','mmmm dd, yyyy')
    warndlg(['You use a MATLAB version older than ',VersionRelease,', for which this skript was written!'])
end
clear VersionRelease

%% Add the folder with the subfunctions to the MATLAB search path

addpath(genpath(FunctionsFolder))

%% Check if all folders and files are available

cd(BasicPath)

%Output from previous script(s)
if exist(InputDataFolder,'dir')==7
    cd(InputDataFolder)
    if ~exist('CalibrationData.txt','file')==2
        error('"CalibrationData.txt" is missing!')
    end
    if ~exist('CalibrationError.txt','file')==2
        error('"CalibrationError.txt" is missing!')
    end
    if ~exist('Constants.txt','file')==2
        error('"Constants.txt" is missing!')
    end
else
    error(['The folder ',InputDataFolder,' is missing!'])
end

%Subfunctions
if exist(FunctionsFolder,'dir')==7
    cd(FunctionsFolder)
    RequiredFiles=[{'absfunc.m'};...
                   {'absorption_calc.m'};...
                   {'fitw_m.m'};...
                   {'loess_m.m'};...
                   {'reflectivity_calc.m'};...
                   {'residualtempcorr.m'}];
    Content=dir;
    Folders=[Content.isdir];
    FileList={Content(~Folders).name}'; 
    if isempty(FileList)
        error(['No functions found in the folder ',RawdataFolder,'.'])
    end
    Index=ismember(RequiredFiles,FileList);
    if sum(Index)<6
        error('One or more custom-made functions are missing! Please check!')
    end             
else
    error(['The folder "',FunctionsFolder,'" is missing!'])
end
clear FileList FileType Content Folders Index RequiredFiles

cd(BasicPath)

%% Data import

cd(InputDataFolder)

%Calibration data
fid=fopen('CalibrationData.txt','r');
Data=textscan(fid,[repmat('%s', 1, 3000) '%*[^\n]'], 'delimiter', '\t', 'collectoutput', true);
Data=[Data{:}];
fclose(fid);

Data=Data(2:end,:);

Calib_Name=unique(Data(:,1),'stable');

AbsCoeff_CalStd_Values=Data(ismember(Data(:,2),{'AbsCoeff_CalStd_Value'}),16:end);
AbsCoeff_CalStd_Values=str2double(AbsCoeff_CalStd_Values);
AbsCoeff_CalStd_Values=AbsCoeff_CalStd_Values(:,~isnan(AbsCoeff_CalStd_Values(1,:)));

Calib_Ref_Timestamp_Start=str2double(Data(ismember(Data(:,2),{'Calib_Ref'}),3:7));
Calib_Ref_Temp=Data(ismember(Data(:,2),{'Calib_Ref'}),13);
Calib_Ref_Temp=str2double(Calib_Ref_Temp);
Calib_Ref_Data=Data(ismember(Data(:,2),{'Calib_Ref'}),16:end);
Calib_Ref_Data=str2double(Calib_Ref_Data);
Calib_Ref_Data=Calib_Ref_Data(:,~isnan(Calib_Ref_Data(1,:)));

Calib_Standard_Timestamp_End=str2double(Data(ismember(Data(:,2),{'Calib_Standard'}),8:12));
Calib_Standard_Temp=Data(ismember(Data(:,2),{'Calib_Standard'}),13);
Calib_Standard_Temp=str2double(Calib_Standard_Temp);
Calib_Standard_Data=Data(ismember(Data(:,2),{'Calib_Standard'}),16:end);
Calib_Standard_Data=str2double(Calib_Standard_Data);
Calib_Standard_Data=Calib_Standard_Data(:,~isnan(Calib_Standard_Data(1,:)));
clear Data ans fid

%Calibration errors
fid=fopen('CalibrationErrors.txt','r');
Data=textscan(fid,[repmat('%s', 1, 3000) '%*[^\n]'], 'delimiter', '\t', 'collectoutput', true);
Data=[Data{:}];
fclose(fid);

AbsCoeff_CalStd_Error=Data(ismember(Data(:,2),{'AbsCoeff_CalStd_Error'}),16:end);
AbsCoeff_CalStd_Error=str2double(AbsCoeff_CalStd_Error);
AbsCoeff_CalStd_Error=AbsCoeff_CalStd_Error(:,~isnan(AbsCoeff_CalStd_Error(1,:)));

Calib_Ref_Error=Data(ismember(Data(:,2),{'Calib_Ref'}),16:end);
Calib_Ref_Error=str2double(Calib_Ref_Error);
Calib_Ref_Error=Calib_Ref_Error(:,~isnan(Calib_Ref_Error(1,:)));

Calib_Standard_Error=Data(ismember(Data(:,2),{'Calib_Standard'}),16:end);
Calib_Standard_Error=str2double(Calib_Standard_Error);
Calib_Standard_Error=Calib_Standard_Error(:,~isnan(Calib_Standard_Error(1,:)));
clear Data ans fid

%Constants data
fid=fopen('Constants.txt','r');
Data1=textscan(fid,'%s',3,'Delimiter','\t');
Data1=[Data1{:}];
Data2=textscan(fid,[repmat('%s', 1, 3000) '%*[^\n]'], 'delimiter', '\t', 'collectoutput', true);
Data2=[Data2{:}];
fclose(fid);

Wavelengths=str2double(Data2(1,2:end));
AbsCoeff_Water=str2double(Data2(2,2:end));
TempCoeff=str2double(Data2(3,2:end));

Wavelengths=Wavelengths(~isnan(Wavelengths));
AbsCoeff_Water=AbsCoeff_Water(~isnan(AbsCoeff_Water));
TempCoeff=TempCoeff(~isnan(TempCoeff));

r=strsplit(Data1{1,1});
r=str2double(r(end));
r0=strsplit(Data1{2,1});
r0=str2double(r0(end));
AbsCoeff_WaterT=strsplit(Data1{3,1});
AbsCoeff_WaterT=str2double(AbsCoeff_WaterT(end));
clear Data1 Data2 fid ans

cd(BasicPath)

%% Creating NaN vectors in case no calibration measurements have been performed

if isempty(AbsCoeff_CalStd_Values)
    AbsCoeff_CalStd_Values=NaN(size(Wavelengths));
    AbsCoeff_CalStd_Error=NaN(size(Wavelengths));
    Calib_Ref_Data=NaN(size(Wavelengths));
    Calib_Ref_Error=NaN(size(Wavelengths));
    Calib_Standard_Data=NaN(size(Wavelengths));
    Calib_Standard_Error=NaN(size(Wavelengths));
end

%% Check for available temperature

TempCorr=cell(size(Calib_Name));
for i=1:length(Calib_Name)
    if isnan(Calib_Ref_Temp(i)) || isnan(Calib_Standard_Temp(i))
        TempCorr(i)={'No'};
        Calib_Ref_Temp(i)=AbsCoeff_WaterT;
        Calib_Standard_Temp(i)=AbsCoeff_WaterT;
    else
        TempCorr(i)={'Yes'};
    end
end
clear i

%% Calculation of reflectivity

Reflectivity=zeros(size(AbsCoeff_CalStd_Values));
Reflectivity_Min=zeros(size(AbsCoeff_CalStd_Values));
Reflectivity_Max=zeros(size(AbsCoeff_CalStd_Values));
for i=1:size(Reflectivity,1)
    %Reflectivity calculated with mean values
    Reflectivity(i,:)=reflectivity_calc(Calib_Ref_Data(i,:),...
                                        Calib_Standard_Data(i,:),...
                                        Calib_Ref_Temp(i),...
                                        Calib_Standard_Temp(i),...
                                        AbsCoeff_CalStd_Values(i,:),...
                                        AbsCoeff_Water,...
                                        AbsCoeff_WaterT,...
                                        TempCoeff,...
                                        r,r0);
                                    
    %Lower limit for reflectivity
    Reflectivity_Min(i,:)=reflectivity_calc(Calib_Ref_Data(i,:)-2.*Calib_Ref_Error(i,:),...
                                            Calib_Standard_Data(i,:)+2.*Calib_Standard_Error(i,:),...
                                            Calib_Ref_Temp(i),...
                                            Calib_Standard_Temp(i),...
                                            AbsCoeff_CalStd_Values(i,:)+AbsCoeff_CalStd_Error(i,:),...
                                            AbsCoeff_Water,...
                                            AbsCoeff_WaterT,...
                                            TempCoeff,...
                                            r,r0);

    %Upper limit for reflectivity
    Reflectivity_Max(i,:)=reflectivity_calc(Calib_Ref_Data(i,:)+2.*Calib_Ref_Error(i,:),...
                                            Calib_Standard_Data(i,:)-2.*Calib_Standard_Error(i,:),...
                                            Calib_Ref_Temp(i),...
                                            Calib_Standard_Temp(i),...
                                            AbsCoeff_CalStd_Values(i,:)-AbsCoeff_CalStd_Error(i,:),...
                                            AbsCoeff_Water,...
                                            AbsCoeff_WaterT,...
                                            TempCoeff,...
                                            r,r0);    
end
clear i

%% Saving the data

%Going to or creating the folder where the working data will be saved
if exist(ResultsFolder,'dir')==0
    mkdir(ResultsFolder)
end

cd(ResultsFolder)

%Save the complete workspace as .mat file
save('ReflectivityCalculation')

%Reflectivity
SaveFileName='Reflectivity.txt';

HeaderFormat=['%s',repmat('\t%s',1,11),repmat('\t%d',1,size(Wavelengths,2)),'\r\n'];
Header=[{'Calibration No./Name'}...
        {'Year (START)'} {'Month (START)'} {'Day (START)'} {'Hour (START)'} {'Minute (START)'}...
        {'Year (END)'} {'Month (END)'} {'Day (END)'} {'Hour (END)'} {'Minute (END)'}...
        {'Temperature correction'} num2cell(Wavelengths)];
DataFormat=['%s',repmat('\t%d',1,10),'\t%s',repmat('\t%f',1,size(Wavelengths,2)),'\r\n'];
Data=[Calib_Name...
      num2cell(Calib_Ref_Timestamp_Start)...
      num2cell(Calib_Standard_Timestamp_End)...
      TempCorr num2cell(Reflectivity)];

fid=fopen(SaveFileName,'w');
fprintf(fid,HeaderFormat,Header{1,:});
for i=1:size(Data,1)
    fprintf(fid,DataFormat,Data{i,:});
end
fclose(fid);
clear i fid ans SaveFileName Header HeaderFormat Data DataFormat

%Reflectivity (lower margin)
SaveFileName='Reflectivity_Min.txt';

HeaderFormat=['%s',repmat('\t%s',1,11),repmat('\t%d',1,size(Wavelengths,2)),'\r\n'];
Header=[{'Calibration No./Name'}...
        {'Year (START)'} {'Month (START)'} {'Day (START)'} {'Hour (START)'} {'Minute (START)'}...
        {'Year (END)'} {'Month (END)'} {'Day (END)'} {'Hour (END)'} {'Minute (END)'}...
        {'Temperature correction'} num2cell(Wavelengths)];
DataFormat=['%s',repmat('\t%d',1,10),'\t%s',repmat('\t%f',1,size(Wavelengths,2)),'\r\n'];
Data=[Calib_Name...
      num2cell(Calib_Ref_Timestamp_Start)...
      num2cell(Calib_Standard_Timestamp_End)...
      TempCorr num2cell(Reflectivity_Min)];

fid=fopen(SaveFileName,'w');
fprintf(fid,HeaderFormat,Header{1,:});
for i=1:size(Data,1)
    fprintf(fid,DataFormat,Data{i,:});
end
fclose(fid);
clear i fid ans SaveFileName Header HeaderFormat Data DataFormat

%Reflectivity (upper margin)
SaveFileName='Reflectivity_Max.txt';

HeaderFormat=['%s',repmat('\t%s',1,11),repmat('\t%d',1,size(Wavelengths,2)),'\r\n'];
Header=[{'Calibration No./Name'}...
        {'Year (START)'} {'Month (START)'} {'Day (START)'} {'Hour (START)'} {'Minute (START)'}...
        {'Year (END)'} {'Month (END)'} {'Day (END)'} {'Hour (END)'} {'Minute (END)'}...
        {'Temperature correction'} num2cell(Wavelengths)];
DataFormat=['%s',repmat('\t%d',1,10),'\t%s',repmat('\t%f',1,size(Wavelengths,2)),'\r\n'];
Data=[Calib_Name...
      num2cell(Calib_Ref_Timestamp_Start)...
      num2cell(Calib_Standard_Timestamp_End)...
      TempCorr num2cell(Reflectivity_Max)];

fid=fopen(SaveFileName,'w');
fprintf(fid,HeaderFormat,Header{1,:});
for i=1:size(Data,1)
    fprintf(fid,DataFormat,Data{i,:});
end
fclose(fid);
clear i fid ans SaveFileName Header HeaderFormat Data DataFormat

cd(BasicPath)

%% End of script

helpdlg({'You can now check or edit the produced text files.'},...
         'Script finished');