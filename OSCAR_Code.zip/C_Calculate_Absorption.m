% Script for calculating absorption coefficient spectra from measurement
% with an Online Hyperspectral Integrating Cavity Absorption Meter OSCAR
% (TriOS GmbH, Germany)
%
% The script requires the output of the scripts "A_Import_OSCAR.m" and 
% "B_Calculate_Reflectivity.m", specifically "Constants.txt",
% "ReferenceData.txt", "SampleData.txt", and "Reflectivity.txt".
%
% The result of this script is a textfile ("Absorption.txt"). It contains
% the absorption coefficient spectra based calculated from the difference 
% of the light intensity during the reference and sample measurements,
% taking into account the reflectivity of the cavity which determines the 
% optical path length. It gives also a quality flag that provides a first
% guess whether the spectrum is of reasonable quality or not (1: quality 
% ok, 0: quality questionable).
%
% For the time periods in between the individual calibration and reference
% measurements, respectively, the data are interpolated to provide
% infomation for the absorption coefficient calculation. The interpolation
% method can be defined in the "Parameters" section below (see also the
% documention regarding the interp1.m function).
% 
% Besides a correction for temperature, the absorption coefficient values 
% also have to be corrected for the influence of salinity on the pure water
% absorption. In case these data are not available, a default salinity
% value can be specified in the "Parameters" section that is used unless no
% other salinity values are given in the "SampleData.txt" file.
%
% Jochen Wollschl�ger
% Institute for Chemistry and Biology of the Marine Environment
% University of Oldenburg
% Contact: jochen.wollschlaeger@uol.de
% 
% Changelog:
%
% Version 1.0: Finished (07.06.2019)
%
% License information:
% Copyright (c) [2019] [Jochen Wollschl�ger]
% Permission is hereby granted, free of charge, to any person obtaining a
% copy of this software and associated documentation files (the "Software"),
% to deal in the Software without restriction, including without limitation
% the rights to use, copy, modify, merge, publish, distribute, sublicense,
% and/or sell copies of the Software, and to permit persons to whom the 
% Software is furnished to do so, subject to the following conditions:
% 
% The above copyright notice and this permission notice shall be included 
% in all copies or substantial portions of the Software.
% 
% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS 
% OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
% MERCHANTABILITY,FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
% IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY 
% CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT
% OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR 
% THE USE OR OTHER DEALINGS IN THE SOFTWARE.
%--------------------------------------------------------------------------

clc
clear
BasicPath=pwd;

%% Parameters

%Path of the folder that contains the output of the previously executed 
%scripts
InputDataFolder=[BasicPath,'\Results'];

%Name of the folder that will contain the output files
%If not existing, the folder will be created
ResultsFolder=[BasicPath,'\Results'];

%Path of the folder that contains the custom-build functions of the script
FunctionsFolder=[BasicPath,'\Subfunctions'];

%Salinity value that is used for salinity correction unless no other value
%is specified
DefaultSalinity=0;

%Interpolation method for the reference and reflectivity data
InterpMethod='linear'; % other options are 'previous' or 'spline'

%Define the range in the NIR which is considered for correction of residual
%temperature effects
NIR_Range=[700:720];

%Define the limits for the residual temperature correction (in �C)
TempResCorrLimit=2;

%Degree of smoothing for the absorption coefficient spectrum (loess.m; 0.01-1)
Smoothing_AbsorptionCoeff=0.05;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%FROM HERE, ONLY MAKE MODIFICATIONS IF YOU KNOW WHAT YOU ARE DOING!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Check the operating system

if ismac
    InputDataFolder=strrep(InputDataFolder,'\','/');
    ResultsFolder=strrep(ResultsFolder,'\','/');
    FunctionsFolder=strrep(FunctionsFolder,'\','/');
elseif isunix
    InputDataFolder=strrep(InputDataFolder,'\','/');
    ResultsFolder=strrep(ResultsFolder,'\','/');
    FunctionsFolder=strrep(FunctionsFolder,'\','/');
elseif ispc
else
    error('Platform not supported')
end

[~,VersionRelease]=version;
if datenum(VersionRelease,'mmmm dd, yyyy')<datenum('January 5, 2019','mmmm dd, yyyy')
    warndlg(['You use a MATLAB version older than ',VersionRelease,', for which this skript was written!'])
end
clear VersionRelease

%% Add the folder with the subfunctions to the MATLAB search path

addpath(genpath(FunctionsFolder))

%% Check if all folders and files are available

cd(BasicPath)

%Output from previous script(s)
if exist(InputDataFolder,'dir')==7
    cd(InputDataFolder)
    if ~exist('Constants.txt','file')==2
        error('"Constants.txt" is missing!')
    end
    if ~exist('ReferenceData.txt','file')==2
        error('"ReferenceData.txt" is missing!')
    end
    if ~exist('ReferenceErrors.txt','file')==2
        error('"ReferenceErrors.txt" is missing!')
    end
    if ~exist('SampleData.txt','file')==2
        error('"SampleData.txt" is missing!')
    end
    if ~exist('Reflectivity.txt','file')==2
        error('"Reflectivity.txt" is missing!')
    end
    if ~exist('Reflectivity_Max.txt','file')==2
        error('"Reflectivity_Max.txt" is missing!')
    end
    if ~exist('Reflectivity_Min.txt','file')==2
        error('"Reflectivity_Min.txt" is missing!')
    end
else
    error(['The folder ',FolderInOutName,' is missing!'])
end

%Subfunctions
if exist(FunctionsFolder,'dir')==7
    cd(FunctionsFolder)
    RequiredFiles=[{'absfunc.m'};...
                   {'absorption_calc.m'};...
                   {'fitw_m.m'};...
                   {'loess_m.m'};...
                   {'reflectivity_calc.m'};...
                   {'residualtempcorr.m'}];
    Content=dir;
    Folders=[Content.isdir];
    FileList={Content(~Folders).name}'; 
    if isempty(FileList)
        error(['No functions found in the folder ',RawdataFolder,'.'])
    end
    Index=ismember(RequiredFiles,FileList);
    if sum(Index)<6
        error('One or more custom-made functions are missing! Please check!')
    end             
else
    error(['The folder "',FunctionsFolder,'" is missing!'])
end
clear FileList FileType Content Folders Index RequiredFiles

%% Import reflectivity data

cd(InputDataFolder)

%Reflectivity
fid=fopen('Reflectivity.txt','r');
Data=textscan(fid,[repmat('%s', 1, 3000) '%*[^\n]'], 'delimiter', '\t', 'collectoutput', true);
Data=[Data{:}];
fclose(fid);

Data=Data(2:end,:);

Reflectivity=Data(:,13:end);
Reflectivity=Reflectivity(:,~cellfun(@isempty,Reflectivity(1,:)));
Reflectivity=str2double(Reflectivity);

Reflectivity_Timestamp_Start=datenum([str2double(Data(:,2:6)) zeros(size(Reflectivity,1),1)]);
Reflectivity_Timestamp_End=datenum([str2double(Data(:,7:11)) zeros(size(Reflectivity,1),1)]);

Reflectivity_Tempcorr=Data(:,12);
clear Data fid ans

%Reflectivity (lower margin)
fid=fopen('Reflectivity_Min.txt','r');
Data=textscan(fid,[repmat('%s', 1, 3000) '%*[^\n]'], 'delimiter', '\t', 'collectoutput', true);
Data=[Data{:}];
fclose(fid);

Data=Data(2:end,:);

Reflectivity_Min=Data(:,13:end);
Reflectivity_Min=Reflectivity_Min(:,~cellfun(@isempty,Reflectivity_Min(1,:)));
Reflectivity_Min=str2double(Reflectivity_Min);
clear Data fid ans

%Reflectivity (upper margin)
fid=fopen('Reflectivity_Max.txt','r');
Data=textscan(fid,[repmat('%s', 1, 3000) '%*[^\n]'], 'delimiter', '\t', 'collectoutput', true);
Data=[Data{:}];
fclose(fid);

Data=Data(2:end,:);
Reflectivity_Max=Data(:,13:end);
Reflectivity_Max=Reflectivity_Max(:,~cellfun(@isempty,Reflectivity_Max(1,:)));
Reflectivity_Max=str2double(Reflectivity_Max);
clear Data fid ans DesiredFormat_Used

%% Import reference data

%Reference mean values
fid=fopen('ReferenceData.txt','r');
Data=textscan(fid,[repmat('%s', 1, 3000) '%*[^\n]'], 'delimiter', '\t', 'collectoutput', true);
Data=[Data{:}];
fclose(fid);

Data=Data(2:end,:);
Ref_Timestamp_Start=datenum([str2double(Data(:,2:6)) zeros(size(Data(:,2:6),1),1)]);
Ref_Timestamp_End=datenum([str2double(Data(:,7:11)) zeros(size(Data(:,7:11),1),1)]);
Ref_Temp=str2double(Data(:,12));
Ref_Data=Data(:,15:end);
Ref_Data=Ref_Data(:,~cellfun(@isempty,Ref_Data(1,:)));
Ref_Data=str2double(Ref_Data);
clear Data fid ans DesiredFormat_Used

%Reference errors
fid=fopen('ReferenceErrors.txt','r');
Data=textscan(fid,[repmat('%s', 1, 3000) '%*[^\n]'], 'delimiter', '\t', 'collectoutput', true);
Data=[Data{:}];
fclose(fid);

Data=Data(2:end,:);
Ref_Errors=Data(:,15:end);
Ref_Errors=Ref_Errors(:,~cellfun(@isempty,Ref_Errors(1,:)));
Ref_Errors=str2double(Ref_Errors);
clear Data fid ans DesiredFormat_Used

%% Import sample data

%Obtain the file format from the file
%(increases the import speed of large data amounts)
fid=fopen('SampleData.txt','r');
Data=textscan(fid,[repmat('%s', 1, 3000) '%*[^\n]'],1, 'delimiter', '\t', 'collectoutput', true);
Data=[Data{:}];
Data=Data(:,~cellfun(@isempty,Data(1,:)));
IndexOfNumerics=~isnan(str2double(Data));
FileFormat=[repmat('%s',1,sum(~IndexOfNumerics)),repmat('%f',1,sum(IndexOfNumerics))];
fclose(fid);
clear IndexOfNumerics Data fid ans

%Import the data with the obtained file format
fid=fopen('SampleData.txt','r');
Data=textscan(fid,[FileFormat '%*[^\n]'], 'delimiter', '\t', 'collectoutput', true);
fclose(fid);
Sample_Name=Data{1,1}(2:end,1);
Sample_Timestamp=datenum(str2double(Data{1,1}(2:end,2:7)));
Sample_Temp=str2double(Data{1,1}(2:end,7));
Sample_Salt=str2double(Data{1,1}(2:end,8));
Sample_Data=Data{1,2}(2:end,:);
clear Data fid ans FileFormat

%% Import Constants data

fid=fopen('Constants.txt','r');
Data1=textscan(fid,'%s',3,'Delimiter','\t');
Data1=[Data1{:}];
Data2=textscan(fid,[repmat('%s', 1, 3000) '%*[^\n]'], 'delimiter', '\t', 'collectoutput', true);
Data2=[Data2{:}];
fclose(fid);

Wavelengths=str2double(Data2(1,2:end));
AbsCoeff_Water=str2double(Data2(2,2:end));
TempCoeff=str2double(Data2(3,2:end));
SaltCoeff=str2double(Data2(4,2:end));

Wavelengths=Wavelengths(~isnan(Wavelengths));
AbsCoeff_Water=AbsCoeff_Water(~isnan(AbsCoeff_Water));
TempCoeff=TempCoeff(~isnan(TempCoeff));
SaltCoeff=SaltCoeff(~isnan(SaltCoeff));

r=strsplit(Data1{1,1});
r=str2double(r(end));
r0=strsplit(Data1{2,1});
r0=str2double(r0(end));
AbsCoeff_WaterT=strsplit(Data1{3,1});
AbsCoeff_WaterT=str2double(AbsCoeff_WaterT(end));
clear Data1 Data2 fid ans

cd(BasicPath)

%% Assigning reflectivity and reference data to the sample measurements

%Interpolation of data over all timestamps
AllTimestamps=unique([Reflectivity_Timestamp_Start;Reflectivity_Timestamp_End;...
                      Ref_Timestamp_Start;Ref_Timestamp_End;Sample_Timestamp]);
Ref_Data_interp=interp1([Ref_Timestamp_Start;Ref_Timestamp_End],[Ref_Data;Ref_Data],...
                        AllTimestamps,InterpMethod,'extrap');
Ref_Errors_interp=interp1([Ref_Timestamp_Start;Ref_Timestamp_End],[Ref_Errors;Ref_Errors],...
                          AllTimestamps,InterpMethod,'extrap');
Ref_Temp_interp=interp1([Ref_Timestamp_Start;Ref_Timestamp_End],[Ref_Temp;Ref_Temp],...
                         AllTimestamps,InterpMethod,'extrap');
Reflectivity_interp=interp1([Reflectivity_Timestamp_Start;Reflectivity_Timestamp_End],[Reflectivity;Reflectivity],...
                            AllTimestamps,InterpMethod,'extrap');
Reflectivity_Min_interp=interp1([Reflectivity_Timestamp_Start;Reflectivity_Timestamp_End],...
                                [Reflectivity_Min;Reflectivity_Min],AllTimestamps,InterpMethod,'extrap');
Reflectivity_Max_interp=interp1([Reflectivity_Timestamp_Start;Reflectivity_Timestamp_End],...
                                [Reflectivity_Max;Reflectivity_Max],AllTimestamps,InterpMethod,'extrap');
                                                                           
Reflectivity_Tempcorr_interp=cell(size(AllTimestamps));
Timestamps_Working=[Reflectivity_Timestamp_End;AllTimestamps(end)];
for i=1:size(Timestamps_Working,1)-1
    Index=[AllTimestamps>=Timestamps_Working(i) AllTimestamps<=Timestamps_Working(i+1)];
    Index=sum(Index,2)>0;
    Reflectivity_Tempcorr_interp(Index)=Reflectivity_Tempcorr(i);
end
clear Index i Timestamps_Working

%Selecting the data for the timestamps of the sample measurements
Index=ismember(AllTimestamps,Sample_Timestamp);
Ref_Data=Ref_Data_interp(Index,:);
Ref_Errors=Ref_Errors_interp(Index,:);
Ref_Temp=Ref_Temp_interp(Index,:);
Reflectivity=Reflectivity_interp(Index,:);
Reflectivity_Min=Reflectivity_Min_interp(Index,:);
Reflectivity_Max=Reflectivity_Max_interp(Index,:);
Reflectivity_Tempcorr=Reflectivity_Tempcorr_interp(Index,:);
clear Index Ref_Mean_interp Ref_Temp_interp Reflectivity_interp...
      Reflectivity_Tempcorr_interp Ref_Data_interp Reflectivity_Min_interp...
      Reflectivity_Max_interp Ref_Errors_interp AllTimestamps

%% Check for available temperature and salinity data

TempCorr=cell(size(Sample_Data,1),1);
for i=1:size(Sample_Data,1)
    if isnan(Sample_Temp(i))||isnan(Ref_Temp(i))
        TempCorr(i)={'No'};
        Sample_Temp(i)=20.1;
        Ref_Temp(i)=20.1;
    else
        TempCorr(i)={'Yes'};
    end
end
clear i

SaltCorr=cell(size(Sample_Data,1),1);
for i=1:size(Sample_Data,1)
    if isnan(Sample_Salt(i))
        SaltCorr(i)={['Used default salinity (',num2str(DefaultSalinity),')']};
        Sample_Salt(i)=DefaultSalinity;
    else
        SaltCorr(i)={'Yes'};
    end
end
clear i
clear DefaultSalinity

%% Absorption coefficient calculation

AbsorptionCoeff=zeros(size(Sample_Data));
AbsorptionCoeff_Min=zeros(size(Sample_Data));
AbsorptionCoeff_Max=zeros(size(Sample_Data));
AbsorptionSpectraToCalculate=size(AbsorptionCoeff,1);
for i=1:size(AbsorptionCoeff,1)
    %Absorption calcualted with mean values
    [abs_coeff]=absorption_calc(Ref_Data(i,:),...
                                Sample_Data(i,:),...
                                Reflectivity(i,:),...
                                AbsCoeff_Water,...
                                AbsCoeff_WaterT,...
                                Ref_Temp(i),...
                                Sample_Temp(i),...
                                TempCoeff,...
                                Sample_Salt(i),...
                                SaltCoeff,...
                                r,r0);
    abs_coeff=loess_m(1:length(abs_coeff),abs_coeff,1:length(abs_coeff),Smoothing_AbsorptionCoeff);
    AbsorptionCoeff(i,:)=abs_coeff;
    
    %Lower Limit of absorption
    [abs_coeff]=absorption_calc(Ref_Data(i,:)-2.*Ref_Errors(i,:),...
                                Sample_Data(i,:),...
                                Reflectivity_Max(i,:),...
                                AbsCoeff_Water,...
                                AbsCoeff_WaterT,...
                                Ref_Temp(i),...
                                Sample_Temp(i),...
                                TempCoeff,...
                                Sample_Salt(i),...
                                SaltCoeff,...
                                r,r0);
    abs_coeff=loess_m(1:length(abs_coeff),abs_coeff,1:length(abs_coeff),Smoothing_AbsorptionCoeff);
    AbsorptionCoeff_Min(i,:)=abs_coeff;
    
    %Upper limit for absorption
    [abs_coeff]=absorption_calc(Ref_Data(i,:)+2.*Ref_Errors(i,:),...
                                Sample_Data(i,:),...
                                Reflectivity_Min(i,:),...
                                AbsCoeff_Water,...
                                AbsCoeff_WaterT,...
                                Ref_Temp(i),...
                                Sample_Temp(i),...
                                TempCoeff,...
                                Sample_Salt(i),...
                                SaltCoeff,...
                                r,r0);
    abs_coeff=loess_m(1:length(abs_coeff),abs_coeff,1:length(abs_coeff),Smoothing_AbsorptionCoeff);
    AbsorptionCoeff_Max(i,:)=abs_coeff;
        
    AbsorptionSpectraToCalculate=AbsorptionSpectraToCalculate-1;
    display(AbsorptionSpectraToCalculate)
end
clear i abs_coeff quality AbsorptionSpectraToCalculate Ref_Mean_Used...
      Ref_Temp_Used Reflectivity_Used Sample Sample_Salt Sample_Temp  
  
%% Correction of residual temperature differences

Index=Wavelengths>min(NIR_Range)&Wavelengths<max(NIR_Range);
NIR_Range=Wavelengths(Index);

Delta_Temp=NaN(size(AbsorptionCoeff,1),1);
for i=1:size(AbsorptionCoeff,1)
    [SpectrumCorr,TempDiff]=residualtempcorr(Wavelengths,AbsorptionCoeff(i,:),TempCoeff,NIR_Range,TempResCorrLimit);
    AbsorptionCoeff(i,:)=SpectrumCorr;    
    Delta_Temp(i,:)=round(TempDiff,2);
    AbsorptionCoeff_Min(i,:)=AbsorptionCoeff_Min(i,:)-(Delta_Temp(i,:).*TempCoeff);
    AbsorptionCoeff_Max(i,:)=AbsorptionCoeff_Max(i,:)+(Delta_Temp(i,:).*TempCoeff);
end
clear i SpectrumCorr TempDiff NIR_Range TempResCorrLimit Index

%% First guess quality check of the absorption coefficient spectra

QualityFlag=zeros(size(Sample_Data,1),1);
QualityFlag_Min=zeros(size(Sample_Data,1),1);
QualityFlag_Max=zeros(size(Sample_Data,1),1);
for i=1:size(AbsorptionCoeff,1)   
    if max(Wavelengths)<700
        QualityFlag(i)=NaN;
        QualityFlag_Min(i)=NaN;
        QualityFlag_Max(i)=NaN;
    else    
        Slope=(AbsorptionCoeff(i,Wavelengths==650)-AbsorptionCoeff(i,Wavelengths==690))/(650-690);
        Slope_Min=(AbsorptionCoeff_Min(i,Wavelengths==650)-AbsorptionCoeff_Min(i,Wavelengths==690))/(650-690);
        Slope_Max=(AbsorptionCoeff_Max(i,Wavelengths==650)-AbsorptionCoeff_Max(i,Wavelengths==690))/(650-690);
        if AbsorptionCoeff(i,Wavelengths==700)>0 && Slope<0
            QualityFlag(i)=1;
        else
            QualityFlag(i)=3;
        end
        if AbsorptionCoeff_Min(i,Wavelengths==700)>0 && Slope_Min<0
            QualityFlag_Min(i)=1;
        else
            QualityFlag_Min(i)=3;
        end
        if AbsorptionCoeff_Max(i,Wavelengths==700)>0 && Slope_Max<0
            QualityFlag_Max(i)=1;
        else
            QualityFlag_Max(i)=3;
        end
    end
end
clear i Slope Slope_Min Slope_Max

%% Convert the timestamp in readable format

Ref_Timestamp_Start=datevec(Ref_Timestamp_Start);
Ref_Timestamp_End=datevec(Ref_Timestamp_End);
Reflectivity_Timestamp_Start=datevec(Reflectivity_Timestamp_Start);
Reflectivity_Timestamp_End=datevec(Reflectivity_Timestamp_End);
Sample_Timestamp=datevec(Sample_Timestamp);

%% Save the data

%Going to or creating the folder where the working data will be saved
if exist(ResultsFolder,'dir')==0
    mkdir(ResultsFolder)
end

cd(ResultsFolder)

%Save the complete workspace as .mat file
save('AbsorptionCalculation')

%Absorption
SaveFileName='Absorption.txt';

HeaderFormat=['%s',repmat('\t%s',1,12),repmat('\t%d',1,size(Wavelengths,2)),'\r\n'];
Header=[{'Sample No./Name'}...
        {'Year'} {'Month'} {'Day'} {'Hour'} {'Minute'} {'Second'}...
        {'Reflec. Temp. corr.'} {'Temp. corr.'} {'Res. Temp. corr.[�C]'} {'Sal. corr.'}...
        {'QualityFlag'} {'Units'} num2cell(Wavelengths)];
DataFormat=['%s',repmat('\t%d',1,6),'\t%s\t%s\t%.2f\t%s\t%.0f\t%s',repmat('\t%f',1,size(Wavelengths,2)),'\r\n'];
Data=[Sample_Name...
      num2cell(Sample_Timestamp)...
      Reflectivity_Tempcorr TempCorr num2cell(Delta_Temp) SaltCorr...
      num2cell(QualityFlag) repmat({'[m-1]'},size(Sample_Name,1),1) num2cell(AbsorptionCoeff)];

fid=fopen(SaveFileName,'w');
fprintf(fid,'%s\r\n',['Interpolation method for reference and reflectivity: ',InterpMethod]);
fprintf(fid,HeaderFormat,Header{1,:});
for i=1:size(Data,1)
    fprintf(fid,DataFormat,Data{i,:});
end
fclose(fid);
clear i fid ans SaveFileName Header HeaderFormat Data DataFormat

%Absorption (lower margin)
SaveFileName='Absorption_Min.txt';

HeaderFormat=['%s',repmat('\t%s',1,12),repmat('\t%d',1,size(Wavelengths,2)),'\r\n'];
Header=[{'Sample No./Name'}...
        {'Year'} {'Month'} {'Day'} {'Hour'} {'Minute'} {'Second'}...
        {'Reflec. Temp. corr.'} {'Temp. corr.'} {'Res. Temp. corr.[�C]'} {'Sal. corr.'}...
        {'QualityFlag'} {'Units'} num2cell(Wavelengths)];
DataFormat=['%s',repmat('\t%d',1,6),'\t%s\t%s\t%.2f\t%s\t%.0f\t%s',repmat('\t%f',1,size(Wavelengths,2)),'\r\n'];
Data=[Sample_Name...
      num2cell(Sample_Timestamp)...
      Reflectivity_Tempcorr TempCorr num2cell(Delta_Temp) SaltCorr...
      num2cell(QualityFlag_Min) repmat({'[m-1]'},size(Sample_Name,1),1) num2cell(AbsorptionCoeff_Min)];

fid=fopen(SaveFileName,'w');
fprintf(fid,'%s\r\n',['Interpolation method for reference and reflectivity: ',InterpMethod]);
fprintf(fid,HeaderFormat,Header{1,:});
for i=1:size(Data,1)
    fprintf(fid,DataFormat,Data{i,:});
end
fclose(fid);
clear i fid ans SaveFileName Header HeaderFormat Data DataFormat

%Absorption (upper margin)
SaveFileName='Absorption_Max.txt';

HeaderFormat=['%s',repmat('\t%s',1,12),repmat('\t%d',1,size(Wavelengths,2)),'\r\n'];
Header=[{'Sample No./Name'}...
        {'Year'} {'Month'} {'Day'} {'Hour'} {'Minute'} {'Second'}...
        {'Reflec. Temp. corr.'} {'Temp. corr.'} {'Res. Temp. corr.[�C]'} {'Sal. corr.'}...
        {'QualityFlag'} {'Units'} num2cell(Wavelengths)];
DataFormat=['%s',repmat('\t%d',1,6),'\t%s\t%s\t%.2f\t%s\t%.0f\t%s',repmat('\t%f',1,size(Wavelengths,2)),'\r\n'];
Data=[Sample_Name...
      num2cell(Sample_Timestamp)...
      Reflectivity_Tempcorr TempCorr num2cell(Delta_Temp) SaltCorr...
      num2cell(QualityFlag_Max) repmat({'[m-1]'},size(Sample_Name,1),1) num2cell(AbsorptionCoeff_Max)];
  
fid=fopen(SaveFileName,'w');
fprintf(fid,'%s\r\n',['Interpolation method for reference and reflectivity: ',InterpMethod]);
fprintf(fid,HeaderFormat,Header{1,:});
for i=1:size(Data,1)
    fprintf(fid,DataFormat,Data{i,:});
end
fclose(fid);
clear i fid ans SaveFileName Header HeaderFormat Data DataFormat

cd(BasicPath)

%% End of script

helpdlg({'You can now check or edit the produced text files.'},...
         'Script finished');