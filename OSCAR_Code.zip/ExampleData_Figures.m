
clc
clear
BasicPath=pwd;

%% Parameters

%Path of the folder that contains the output of the previously executed 
%scripts
ResultsFolder=[BasicPath,'\Results'];
FigureName='DAT Dataset';

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%FROM HERE, ONLY MAKE MODIFICATIONS IF YOU KNOW WHAT YOU ARE DOING!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

cd(ResultsFolder)

%% Plot reflectivity

load('ReflectivityCalculation.mat')

figure('Name',FigureName)
FigureProperties=gcf;
FigureProperties.Position=[300   100   800   1000];
subplot(3,1,1)
hold on
plot(Wavelengths,Reflectivity(1,:),'LineWidth',1.5,'LineStyle','-','Color',[0/255 0/255 0/255])
plot(Wavelengths,Reflectivity_Min(1,:),'LineWidth',1.5,'LineStyle','--','Color',[100/255 100/255 100/255])
plot(Wavelengths,Reflectivity_Max(1,:),'LineWidth',1.5,'LineStyle','--','Color',[100/255 100/255 100/255])
hold off
AxisProperties=gca;
AxisProperties.XLim=[Wavelengths(1)-10 Wavelengths(end)+10];
AxisProperties.YLim=[0.9 1];
AxisProperties.FontSize=16;
ylabel('Reflectivity','FontSize',20,'FontWeight','bold','Interpreter','None')
text(Wavelengths(round(numel(Wavelengths)./2)),0.99,Calib_Name{1,:},...
     'Interpreter','None',...
     'FontSize',16,...
     'FontWeight','bold',...
     'HorizontalAlignment','center')
box on

clearvars -except BasicPath ResultsFolder FigureName

%% Plot absorption

load('AbsorptionCalculation.mat')

subplot(3,1,2)
hold on
plot(Wavelengths,AbsorptionCoeff(2,:),'LineWidth',1.5,'LineStyle','-','Color',[0/255 0/255 0/255])
plot(Wavelengths,AbsorptionCoeff_Min(2,:),'LineWidth',1.5,'LineStyle','--','Color',[100/255 100/255 100/255])
plot(Wavelengths,AbsorptionCoeff_Max(2,:),'LineWidth',1.5,'LineStyle','--','Color',[100/255 100/255 100/255])
hold off
AxisProperties=gca;
AxisProperties.XLim=[Wavelengths(1)-10 Wavelengths(end)+10];
AxisProperties.YLim=[0 max(AbsorptionCoeff(2,:)).*1.2];
AxisProperties.FontSize=16;
ylabel('a [m^-^1]','FontSize',20,'FontWeight','bold','Interpreter','Tex')
text(Wavelengths(round(numel(Wavelengths)./2)),max(AbsorptionCoeff(2,:)).*1.05,Sample_Name{2,:},...
     'Interpreter','None',...
     'FontSize',16,...
     'FontWeight','bold',...
     'HorizontalAlignment','center')
box on

subplot(3,1,3)
hold on
plot(Wavelengths,AbsorptionCoeff(end-1,:),'LineWidth',1.5,'LineStyle','-','Color',[0/255 0/255 0/255])
plot(Wavelengths,AbsorptionCoeff_Min(end-1,:),'LineWidth',1.5,'LineStyle','--','Color',[100/255 100/255 100/255])
plot(Wavelengths,AbsorptionCoeff_Max(end-1,:),'LineWidth',1.5,'LineStyle','--','Color',[100/255 100/255 100/255])
hold off
AxisProperties=gca;
AxisProperties.XLim=[Wavelengths(1)-10 Wavelengths(end)+10];
AxisProperties.YLim=[0 max(AbsorptionCoeff(3,:)).*1.2];
AxisProperties.FontSize=16;
xlabel('Wavelength [nm]','FontSize',20,'FontWeight','bold','Interpreter','None')
ylabel('a [m^-^1]','FontSize',20,'FontWeight','bold','Interpreter','Tex')
text(Wavelengths(round(numel(Wavelengths)./2)),max(AbsorptionCoeff(3,:)).*1.05,Sample_Name{end-1,:},...
     'Interpreter','None',...
     'FontSize',16,...
     'FontWeight','bold',...
     'HorizontalAlignment','center')
box on

saveas(gcf,[FigureName,'.jpeg'])
clearvars -except BasicPath ResultsFolder

cd(BasicPath)