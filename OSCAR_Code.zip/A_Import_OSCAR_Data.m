% Script for importing data from the Online Hyperspectral Integrating 
% Cavity Absorption Meter (OSCAR; TriOS GmbH, Germany)
%
% The script imports either the ".dat" or ".csv" files provided by the 
% instrument. It is required that the user uses both the "RAW_DARK" and
% the "RAW_LIGH" files that are obtained after unzipping the .tar file
% downloaded from the OSCAR. The files have to be put in a folder which 
% path can be specified in the "Parameters" section below. 
%
% Furthermore, the script imports information necessary for further
% processing of the data. This includes information about the time of 
% calibrations, reference and sample measurements, as well as the
% coefficients for water absorption, temperature and salinity corrections 
% used in the later processing. Also the diameter of the cavity used can be
% specified. The information have to be provided by the user in the 
% Microsoft Excel file ("User_Input.xlsx"). Instructions for filling out 
% the tables are provided in a seperate sheet in this file.
%
% All data vectors will be interpolated on a common interval (to be 
% determined in the "Parameters" section below) and vector length 
% (determined by the smallest and largest wavelength available). The 
% interpolation is performed by the function 'loess_m.m' that is included at
% the end of the script with its subfunction ('fitw_m.m').The degree of 
% smoothing can be determined separately for the different data in the
% "Parameters" section below.
%
% Finally, the data will be provided as six textfiles:
%    1. "CalibrationData.txt"
%       Contains the calibration reference and standard measurement as well
%       as the absorption coefficient spectra of the standards used. The 
%       measurements are the mean values of the periods specified in the
%       Excel sheet.
%    2. "CalibrationErrors.txt"
%       Contains the errors associated with the calibration measurements.
%    3. "Constants.txt"
%       Contains the specified coefficients for water absorption,
%       temperature and salinity correction and cavity radius.
%    4. "ReferenceData.txt"
%       Contains the measurements specified as reference. They are the mean
%       values of the periods specified in the Excel sheet.
%    5. "ReferenceErrors.txt"
%       Contains the errors (standard deviation) of the mean values which
%       represents the reference measurements.
%    6. "SampleData.txt"
%       Contains the measurements specified as samples.
% 
% The data in the text files can be edited and corrected, if necessary (e.g.
% temperature and salinity values for subsequent corrections). 
% However, do not change the length of individual vectors, as this causes
% problems for importing the data with the subsequent scripts.
% 
% Jochen Wollschl�ger
% Institute for Chemistry and Biology of the Marine Environment
% University of Oldenburg
% Contact: jochen.wollschlaeger@uol.de
% 
% Changelog:
%
% Version 1.0: Finished (07.06.2019)
% Version 1.1: Addition of the import of error values of the Calibration
%              Standard data, as well as an calculation of the error 
%              (standard deviation) of the reference measurements. Both 
%              serve as input to the subsequent scripts (17.09.2019)
%
% License information:
% Copyright (c) [2019] [Jochen Wollschl�ger]
% Permission is hereby granted, free of charge, to any person obtaining a
% copy of this software and associated documentation files (the "Software"),
% to deal in the Software without restriction, including without limitation
% the rights to use, copy, modify, merge, publish, distribute, sublicense,
% and/or sell copies of the Software, and to permit persons to whom the 
% Software is furnished to do so, subject to the following conditions:
% 
% The above copyright notice and this permission notice shall be included 
% in all copies or substantial portions of the Software.
% 
% THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS 
% OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF 
% MERCHANTABILITY,FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
% IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY 
% CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT
% OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR 
% THE USE OR OTHER DEALINGS IN THE SOFTWARE.
%-----------------------------------

clc
clear
BasicPath=pwd;

%% Parameters

%Path of the folder that contains the raw data
InputDataFolder=[BasicPath,'\Rawdata']; %Example, can be replaced by any path

%Name of the folder that will contain the output files
%If not existing, the folder will be created
ResultsFolder=[BasicPath,'\Results']; %Example, can be replaced by any path

%Path of the folder that contains the custom-build functions of the script
FunctionsFolder=[BasicPath,'\Subfunctions'];

%Spectral interval of output data (in nm)
Interval=2;

%Degree of smoothing for the OSCAR data (loess.m; 0.01-1)
Smoothing_OSCAR=0.05;

%Degree of smoothing for the constants data (loess.m; 0.01-1)
Smoothing_Constants=0.05;

%Degree of smoothing for the absorption coefficient spectra of the standard
%(loess.m; 0.01-1)
Smoothing_Standard=0.1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%FROM HERE, ONLY MAKE MODIFICATIONS IF YOU KNOW WHAT YOU ARE DOING!
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%% Check the operating system

if ismac
    InputDataFolder=strrep(InputDataFolder,'\','/');
    ResultsFolder=strrep(ResultsFolder,'\','/');
    FunctionsFolder=strrep(FunctionsFolder,'\','/');
elseif isunix
    InputDataFolder=strrep(InputDataFolder,'\','/');
    ResultsFolder=strrep(ResultsFolder,'\','/');
    FunctionsFolder=strrep(FunctionsFolder,'\','/');
elseif ispc
else
    error('Platform not supported')
end

[~,VersionRelease]=version;
if datenum(VersionRelease,'mmmm dd, yyyy')<datenum('January 5, 2019','mmmm dd, yyyy')
    warndlg(['You use a MATLAB version older than ',VersionRelease,', for which this skript was written!'])
end
clear VersionRelease

%% Add the folder with the subfunctions to the MATLAB search path

addpath(genpath(FunctionsFolder))

%% Check if all required folders and files are available

cd(BasicPath)

%User input file
if ~exist('User_Input.xlsx','file')==2
    error('"User_Input.xlsx" is missing!')
end

%Rawdata
if exist(InputDataFolder,'dir')==7
    cd(InputDataFolder)
    Content=dir;
    Folders=[Content.isdir];
    FileList={Content(~Folders).name}';
    if isempty(FileList)
        error(['No ".csv" or ".dat" files found in the folder ',InputDataFolder,'.'])
    end
    FileType=cellfun(@strsplit,FileList,repmat({'.'},size(FileList)),'UniformOutput',0);
    FileType=vertcat(FileType{:});
    FileType=FileType(:,end);
    FileTypePresent=ismember([{'CSV'} {'DAT'}],FileType);    
    if isequal([true true],FileTypePresent) %both files files present
        error(['Both ".csv" and ".dat" files found. Please have only one type of file in the folder ',InputDataFolder,'.'])      
    end                
else
    error(['The folder "',InputDataFolder,'" is missing!'])
end
clear FileList FileType Content Folders

%Subfunctions
if exist(FunctionsFolder,'dir')==7
    cd(FunctionsFolder)
    RequiredFiles=[{'absfunc.m'};...
                   {'absorption_calc.m'};...
                   {'fitw_m.m'};...
                   {'loess_m.m'};...
                   {'reflectivity_calc.m'};...
                   {'residualtempcorr.m'}];
    Content=dir;
    Folders=[Content.isdir];
    FileList={Content(~Folders).name}'; 
    if isempty(FileList)
        error(['No functions found in the folder ',InputDataFolder,'.'])
    end
    Index=ismember(RequiredFiles,FileList);
    if sum(Index)<6
        error('One or more custom-made functions are missing! Please check!')
    end             
else
    error(['The folder "',FunctionsFolder,'" is missing!'])
end
clear FileList FileType Content Folders Index RequiredFiles

cd(BasicPath)

%% Import of user input from Excel-file

%Calibration measurements
[~,~,Raw]=xlsread('User_Input.xlsx','Calibrations');
Index=cellfun(@isnan,Raw(:,1),'UniformOutput',0);
Index=cellfun(@any,Index);
Raw=Raw(~Index,:);
Input=Raw(2:end,:);
if isempty(Input)
    Calib_Name={'No calibration performed'};
    Calib_Ref_Timestamp_Start=datenum([2001 1 1 0 0 0]);
    Calib_Ref_Timestamp_End=datenum([2001 1 1 0 1 0]);
    Calib_Std_Timestamp_Start=datenum([2001 1 1 0 2 0]);
    Calib_Std_Timestamp_End=datenum([2001 1 1 0 3 0]);
    AbsCoeff_CalStd_Name={'None'};
else
    Calib_Name=Input(:,1);
    Calib_Ref_Timestamp_Start=datenum([cell2mat(Input(:,2:6)) zeros(size(Input,1),1)]);
    Calib_Ref_Timestamp_End=datenum([cell2mat(Input(:,7:11)) zeros(size(Input,1),1)]);
    Calib_Std_Timestamp_Start=datenum([cell2mat(Input(:,12:16)) zeros(size(Input,1),1)]);
    Calib_Std_Timestamp_End=datenum([cell2mat(Input(:,17:21)) zeros(size(Input,1),1)]);
    AbsCoeff_CalStd_Name=Input(:,22);
end
clear Raw Index Input

%Calibration Standards (Values)
[~,~,Raw]=xlsread('User_Input.xlsx','Calibration Standards Values');
Index=cellfun(@isnan,Raw(:,1),'UniformOutput',0);
Index=cellfun(@any,Index);
Raw=Raw(~Index,:);
if strcmp(AbsCoeff_CalStd_Name,{'None'})
    Wavelengths_CalStd_Value=350:2:720;
    AbsCoeff_CalStd_Value=NaN(size(Wavelengths_CalStd_Value));
else
    Wavelengths_CalStd_Value=cell2mat(Raw(2:end,1))';
    AbsCoeff_CalStd_Value=NaN(numel(AbsCoeff_CalStd_Name),numel(Wavelengths_CalStd_Value));
    for i=1:size(AbsCoeff_CalStd_Name,1)
        Index=strcmp(Raw(1,:),AbsCoeff_CalStd_Name(i));
        if sum(Index)==0
            error('Name of absorption standard in sheet "Calibrations" and sheet "Calibration Standards Values" does not match!')
        end
        AbsCoeff_CalStd_Value(i,:)=cell2mat(Raw(2:end,Index));
    end
    clear i Index
end

%Calibration Standards (Errors)
[~,~,Raw]=xlsread('User_Input.xlsx','Calibration Standards Errors');
Index=cellfun(@isnan,Raw(:,1),'UniformOutput',0);
Index=cellfun(@any,Index);
Raw=Raw(~Index,:);
if strcmp(AbsCoeff_CalStd_Name,{'None'})
    Wavelengths_CalStd_Error=350:2:720;
    AbsCoeff_CalStd_Error=zeros(size(Wavelengths_CalStd_Error));
else
    Wavelengths_CalStd_Error=cell2mat(Raw(2:end,1))';
    AbsCoeff_CalStd_Error=zeros(numel(AbsCoeff_CalStd_Name),numel(Wavelengths_CalStd_Value));
    for i=1:size(AbsCoeff_CalStd_Name,1)      
        Index=strcmp(Raw(1,:),AbsCoeff_CalStd_Name(i));
        if sum(Index>0)
            AbsCoeff_CalStd_Error(i,:)=cell2mat(Raw(2:end,Index));
        end
    end
    clear i Index
end

%Reference measurements
[~,~,Raw]=xlsread('User_Input.xlsx','Reference measurements');
Index=cellfun(@isnan,Raw(:,1),'UniformOutput',0);
Index=cellfun(@any,Index);
Raw=Raw(~Index,:);
Raw=Raw(2:end,:);
if isempty(Raw)
    error('No reference measurements specified!')
else
    Ref_Name=Raw(:,1);
    Ref_Timestamp_Start=datenum([cell2mat(Raw(:,2:6)) zeros(size(Raw,1),1)]);
    Ref_Timestamp_End=datenum([cell2mat(Raw(:,7:11)) zeros(size(Raw,1),1)]);
end
clear Raw Index

%Sample measurements
[~,~,Raw]=xlsread('User_Input.xlsx','Sample measurements');
Index=cellfun(@isnan,Raw(:,1),'UniformOutput',0);
Index=cellfun(@any,Index);
Raw=Raw(~Index,:);
Raw=Raw(2:end,:);
if isempty(Raw)
    error('No sample measurements specified!')
else
    Sample_Name=Raw(:,1);
    Sample_Timestamp_Start=datenum([cell2mat(Raw(:,2:6)) zeros(size(Raw,1),1)]);
    Sample_Timestamp_End=datenum([cell2mat(Raw(:,7:11)) zeros(size(Raw,1),1)]);
end
clear Raw Index

%Constants
[~,~,Raw]=xlsread('User_Input.xlsx','Constants');
Index=cellfun(@isnan,Raw(:,1),'UniformOutput',0);
Index=cellfun(@any,Index);
Raw=Raw(~Index,:);
Raw=cell2mat(Raw(2:end,:));
if isempty(Raw)
    error('No constants data given!')
end
if isnan(Raw(:,1))
    error('No wavelengths available for the constants!')
else
    Constants_Wavelengths=transpose(Raw(:,1));
end
if isnan(Raw(:,2))
    error('No water absorption coeffients given!')
else
    AbsCoeff_Water=transpose(Raw(:,2));
end
if isnan(Raw(:,3))
    error('No temperature correction coefficients given!')
else
    TempCoeff=transpose(Raw(:,3));
end
if isnan(Raw(:,4))
    error('No salinity correction coefficients given!')
else
    SaltCoeff=transpose(Raw(:,4));
end
if isnan(Raw(:,5))
    error('The temperature at which the absorption coefficients of pure water has been determined is missing!')
else
    AbsCoeff_WaterT=transpose(Raw(1,5));
end
if isnan(Raw(1,6))
    error('The radius of the cavity is not specified!')
else
    r=Raw(1,6);
end
if isnan(Raw(1,7))
    error('The radius of the cavity minus the radius of the quartz ball is not specified!')
else
    r0=Raw(1,7);
end
clear Raw Index

%% Checking the timestamps given in the manual input

%Start-time of measurement smaller than end-time of measurement?
if sum(~(Calib_Ref_Timestamp_Start<Calib_Ref_Timestamp_End))>0
    error('Check Calibration Reference times in Excel file');
end
if sum(~(Calib_Std_Timestamp_Start<Calib_Std_Timestamp_End))>0
    error('Check Calibration Standard times in Excel file');
end
if sum(~(Ref_Timestamp_Start<Ref_Timestamp_End))>0
    error('Check Reference times in Excel file');
end
if sum(~(Sample_Timestamp_Start<Sample_Timestamp_End))>0
    error('Check Calibration Reference times in Excel file');
end

%% Checking calibration standard values and errors

AbsCoeff_CalStd_Error(isnan(AbsCoeff_CalStd_Error))=0;
if size(AbsCoeff_CalStd_Value,2)~=size(AbsCoeff_CalStd_Error,2)
    error('Check vector lengths of Calibration Standard Values and Errors!')
end
Wavelengths_CalStd=Wavelengths_CalStd_Value;
clear Wavelengths_CalStd_Errors Wavelengths_CalStd_Values

%% Import OSCAR data

cd(InputDataFolder)

%Creating a list of all files present in the folder containing the raw data
Content=dir;
Folders=[Content.isdir];
FileList={Content(~Folders).name}';
clear Content Folders

%Opening the files one after another and merge the data
OSCAR_Timestamp=cell(length(FileList),1);
OSCAR_SpectrumType=cell(length(FileList),1);
OSCAR_IntTime=cell(length(FileList),1);
OSCAR_Wavelengths=cell(length(FileList),1);
OSCAR_Data=cell(length(FileList),1);

if isequal([true false],FileTypePresent) % Data is given as .CSV files
    for i=1:size(FileList,1)
        
        fid=fopen(FileList{i});
        Format=repmat({'%s'},1,500);
        Header=textscan(fid,cell2mat(Format),1,'delimiter',',','EmptyValue',NaN);
        Header=cellfun(@strrep,Header,repmat({''''},size(Header)),repmat({''},size(Header)));
        Header=str2double(Header);
        Index=isnan(Header);
        Format(~Index)={'%f'};
        FileContent=textscan(fid,cell2mat(Format),'delimiter',',','EmptyValue',NaN);
        
        %Obtain the timestamps
        OSCAR_Timestamp{i,1}=FileContent{1};
        
        %Obtain the spectrum type
        OSCAR_SpectrumType{i,1}=FileContent{7};
        
        %Obtain the integration time
        OSCAR_IntTime{i,1}=FileContent{11};
        
        %Obtain wavelengths and measured spectra
        OSCAR_Wavelengths{i,1}=Header(~Index);
        OSCAR_Data{i,1}=cell2mat(FileContent(~Index));
        fclose(fid);
    end
    clear i Index fid ans Format FileContent
    OSCAR_Wavelengths=unique(cell2mat(OSCAR_Wavelengths),'rows');
    OSCAR_Timestamp=vertcat(OSCAR_Timestamp{:});
    OSCAR_Timestamp=datenum(OSCAR_Timestamp,'yyyy/mm/dd HH:MM:SS');
    OSCAR_SpectrumType=vertcat(OSCAR_SpectrumType{:});
    OSCAR_IntTime=vertcat(OSCAR_IntTime{:});
    OSCAR_IntTime=str2double(OSCAR_IntTime);
    OSCAR_Data=cell2mat(OSCAR_Data);
    
elseif isequal([false true],FileTypePresent) %Data is given as .DAT files    
    for i=1:size(FileList,1)
        fid=fopen(FileList{i});
        RawData=textscan(fid,'%s%s%s%s%*[^\n]','delimiter',' ','CommentStyle','[','EmptyValue',NaN);
        fclose(fid);
        clear fid ans

        %Obtain the timestamps
        Index=ismember(RawData{1}, {'DateTime'});
        OSCAR_Timestamp{i,1}=datenum(cell2mat([RawData{3}(Index) RawData{4}(Index)]),'yyyy-mm-ddHH:MM:SS');
        clear Index
        
        %Obtain the spectrum type
        Index=ismember(RawData{1}, {'SpectrumType'});
        OSCAR_SpectrumType{i,1}=RawData{3}(Index);        
        clear Index
        
        %Obtain the integration time
        Index=ismember(RawData{1}, {'IntegrationTime'});
        OSCAR_IntTime{i,1}=str2double(RawData{3}(Index));        
        clear Index

        %Obtain wavelengths and measured spectra
        Wavelengths=str2double(RawData{1});
        Data=str2double(RawData{2});
        Index=isnan(Wavelengths);
        Wavelengths=Wavelengths(~Index);
        Data=Data(~Index);
        Index=Wavelengths==0;
        Wavelengths=Wavelengths(~Index);
        Data=Data(~Index);
        WavelengthsUnique=unique(Wavelengths,'stable');
        Spectra=NaN(length(OSCAR_Timestamp{i,1}),length(WavelengthsUnique));
        for j=1:length(WavelengthsUnique)
            Index=Wavelengths==WavelengthsUnique(j);
            OneWavelength=Data(Index);
            Spectra(:,j)=OneWavelength;
        end
        OSCAR_Wavelengths{i,1}=WavelengthsUnique';
        OSCAR_Data{i,1}=Spectra;
        clear j WavelengthsUnique Index RawData Data OneWavelength Spectra...
              Wavelengths     
    end
    OSCAR_Wavelengths=unique(cell2mat(OSCAR_Wavelengths),'rows');
    OSCAR_SpectrumType=vertcat(OSCAR_SpectrumType{:});
    OSCAR_IntTime=cell2mat(OSCAR_IntTime);
    OSCAR_Timestamp=cell2mat(OSCAR_Timestamp);
    OSCAR_Data=cell2mat(OSCAR_Data);  
end
clear i RawData fid ans FileList FileTypePresent

%% Calculating the spectra

%Normalizing all data on integration time
OSCAR_Data=OSCAR_Data./repmat(OSCAR_IntTime,1,size(OSCAR_Data,2));
clear OSCAR_IntTime

%Division in dark and light spectra
Index=ismember(OSCAR_SpectrumType,{'RAW_Dark'});
OSCAR_Timestamp_Dark=OSCAR_Timestamp(Index,:);
OSCAR_Timestamp_Light=OSCAR_Timestamp(~Index,:);
OSCAR_Data_Dark=OSCAR_Data(Index,:);
OSCAR_Data_Light=OSCAR_Data(~Index,:);
clear Index OSCAR_SpectrumType

%Check whether each light spectrum has a corresponding dark spectrum
if size(OSCAR_Data_Light,1)==size(OSCAR_Data_Dark,1)
    if sum(OSCAR_Timestamp_Dark-OSCAR_Timestamp_Light)==0
    else
        error('There are differences in the timestamps of dark and light spectra!')
    end
else
    error('Something is wrong with the number of dark and light spectra!')
end

%Subtracting dark spectra from light spectra
OSCAR_Timestamp=OSCAR_Timestamp_Light;
OSCAR_Data=OSCAR_Data_Light-OSCAR_Data_Dark;
clear OSCAR_Data_Dark OSCAR_Data_Light OSCAR_Timestamp_Dark OSCAR_Timestamp_Light

%Deletion of doubled timestamps and corresponding data
[OSCAR_Timestamp,Index,~]=unique(OSCAR_Timestamp);
OSCAR_Data=OSCAR_Data(Index,:);
clear Index

%% Restricting the data to wavelengths that are available for all parameters

%Determination of minimum/maximum wavelength available
WavelengthMinimum=max([min(Constants_Wavelengths),min(Wavelengths_CalStd),min(OSCAR_Wavelengths)]);
WavelengthMaximum=min([max(Constants_Wavelengths),max(Wavelengths_CalStd),max(OSCAR_Wavelengths)]);

%Restricting the "Constants"-data
Index=Constants_Wavelengths>=WavelengthMinimum&Constants_Wavelengths<=WavelengthMaximum;
Constants_Wavelengths=Constants_Wavelengths(:,Index);
AbsCoeff_Water=AbsCoeff_Water(:,Index);
TempCoeff=TempCoeff(:,Index);
SaltCoeff=SaltCoeff(:,Index);
clear Index

%Restricting the absorption coefficient spectra of the calibration standards
Index=Wavelengths_CalStd>=WavelengthMinimum&Wavelengths_CalStd<=WavelengthMaximum;
Wavelengths_CalStd=Wavelengths_CalStd(:,Index);
AbsCoeff_CalStd_Value=AbsCoeff_CalStd_Value(:,Index);
AbsCoeff_CalStd_Error=AbsCoeff_CalStd_Error(:,Index);
clear Index

%Restricting the OSCAR data
Index=OSCAR_Wavelengths>=WavelengthMinimum&OSCAR_Wavelengths<=WavelengthMaximum;
OSCAR_Wavelengths=OSCAR_Wavelengths(:,Index);
OSCAR_Data=OSCAR_Data(:,Index);
clear Index

%% Interpolation of the spectra according to the parameters set

%Setting wavelength range and interval
Wavelengths=WavelengthMinimum:Interval:WavelengthMaximum;
clear WavelengthMinimum Interval WavelengthMaximum

%Interpolating the "Constants"-data
AbsCoeff_Water=loess_m(Constants_Wavelengths,AbsCoeff_Water,Wavelengths,Smoothing_Constants);
TempCoeff=loess_m(Constants_Wavelengths,TempCoeff,Wavelengths,Smoothing_Constants);
SaltCoeff=loess_m(Constants_Wavelengths,SaltCoeff,Wavelengths,Smoothing_Constants);
clear ConstantsWavelengths

%Interpolating the absorption coefficient spectra of the calibration standards
New_AbsCoeff_CalStd=NaN(size(AbsCoeff_CalStd_Value,1),size(Wavelengths,2));
New_AbsCoeff_CalStd_Error=NaN(size(AbsCoeff_CalStd_Value,1),size(Wavelengths,2));
for i=1:size(AbsCoeff_CalStd_Value,1)
    New_AbsCoeff_CalStd(i,:)=loess_m(Wavelengths_CalStd,AbsCoeff_CalStd_Value(i,:),Wavelengths,Smoothing_Standard);
    New_AbsCoeff_CalStd_Error(i,:)=loess_m(Wavelengths_CalStd,AbsCoeff_CalStd_Error(i,:),Wavelengths,Smoothing_Standard);
end
AbsCoeff_CalStd_Value=New_AbsCoeff_CalStd;
AbsCoeff_CalStd_Error=New_AbsCoeff_CalStd_Error;
clear i New_AbsCoeff_Standard Wavelengths_CalStd New_AbsCoeff_CalStd_Error

%Interpolating the OSCAR data
New_OSCAR_Data=zeros(size(OSCAR_Data,1),size(Wavelengths,2));
InterpolationsToDo=size(OSCAR_Data,1);
for i=1:size(OSCAR_Data,1)
    New_OSCAR_Data(i,:)=loess_m(OSCAR_Wavelengths,OSCAR_Data(i,:),Wavelengths,Smoothing_OSCAR);
    InterpolationsToDo=InterpolationsToDo-1;
    display(InterpolationsToDo)
end
OSCAR_Data=New_OSCAR_Data;
clear i New_OSCAR_Data InterpolationsToDo OSCAR_Wavelengths

cd(BasicPath)

%% Division of the data into the different types of measurement

%Calibration Reference measurements
Calib_Ref_Data=NaN(size(Calib_Name,1),size(OSCAR_Data,2));
Calib_Ref_Error=NaN(size(Calib_Name,1),size(OSCAR_Data,2));
Calib_Ref_N=NaN(size(Calib_Name,1),1);
for i=1:size(Calib_Name,1)
    Index=OSCAR_Timestamp>Calib_Ref_Timestamp_Start(i)&OSCAR_Timestamp<Calib_Ref_Timestamp_End(i);
    Calib_Ref_Data(i,:)=mean(OSCAR_Data(Index,:),1,'omitnan');
    Calib_Ref_Error(i,:)=std(OSCAR_Data(Index,:),0,1,'omitnan');
    Calib_Ref_N(i,:)=numel(OSCAR_Data(Index,1));
end
clear i Index

%Calibration Standard measurements
Calib_Standard_Data=NaN(size(Calib_Name,1),size(OSCAR_Data,2));
Calib_Standard_Error=NaN(size(Calib_Name,1),size(OSCAR_Data,2));
Calib_Standard_N=NaN(size(Calib_Name,1),1);
for i=1:size(Calib_Name,1)
    Index=OSCAR_Timestamp>Calib_Std_Timestamp_Start(i)&OSCAR_Timestamp<Calib_Std_Timestamp_End(i);
    Calib_Standard_Data(i,:)=mean(OSCAR_Data(Index,:),1,'omitnan');
    Calib_Standard_Error(i,:)=std(OSCAR_Data(Index,:),0,1,'omitnan');
    Calib_Standard_N(i,:)=numel(OSCAR_Data(Index,1));
end
clear i Index

%Reference measurements
Ref_Data=cell(size(Ref_Name,1),1);
Ref_Error=cell(size(Ref_Name,1),1);
Ref_N=NaN(size(Ref_Name,1),1);
for i=1:size(Ref_Name,1)
    Index=OSCAR_Timestamp>Ref_Timestamp_Start(i)&OSCAR_Timestamp<Ref_Timestamp_End(i);
    if sum(Index>0)
        Ref_Data{i,:}=mean(OSCAR_Data(Index,:),1,'omitnan');
        Ref_Error{i,:}=std(OSCAR_Data(Index,:),0,1,'omitnan');
        Ref_N(i,:)=numel(OSCAR_Data(Index,1));
    end
end
Ref_Data=cell2mat(Ref_Data);
Ref_Error=cell2mat(Ref_Error);
if isempty(Ref_Data)
    error('No data found at the timestamps specified as Reference measurements!')
end
clear i Index

%Sample measurements
Sample_Data=cell(size(Sample_Name,1),1);
Sample_Timestamp=cell(size(Sample_Name,1),1);
Sample_Name_extended=cell(size(Sample_Name,1),1);
for i=1:size(Sample_Name,1)
    Index=OSCAR_Timestamp>Sample_Timestamp_Start(i)&OSCAR_Timestamp<Sample_Timestamp_End(i);
    Sample_Data{i,1}=OSCAR_Data(Index,:);
    Sample_Timestamp{i,1}=OSCAR_Timestamp(Index,:);
    Sample_Name_extended{i,1}=repmat(Sample_Name(i,1),sum(Index),1);
end
Sample_Data=cell2mat(Sample_Data);
Sample_Timestamp=cell2mat(Sample_Timestamp);
Sample_Name=vertcat(Sample_Name_extended{:});
if isempty(Sample_Data)
    error('No data found at the timestamps specified as Sample measurements!')
end
clear i Index OSCAR_Data OSCAR_Timestamp Sample_Name_extended

%% Converting the timestamps back in vector format

if strcmp(Calib_Name,{'No calibration performed'})
    Calib_Ref_Timestamp_Start=NaN(1,5);
    Calib_Ref_Timestamp_End=NaN(1,5);

    Calib_Std_Timestamp_Start=NaN(1,5);
    Calib_Std_Timestamp_End=NaN(1,5);
else
    Calib_Ref_Timestamp_Start=datevec(Calib_Ref_Timestamp_Start);
    Calib_Ref_Timestamp_Start=Calib_Ref_Timestamp_Start(:,1:5);
    Calib_Ref_Timestamp_End=datevec(Calib_Ref_Timestamp_End);
    Calib_Ref_Timestamp_End=Calib_Ref_Timestamp_End(:,1:5);

    Calib_Std_Timestamp_Start=datevec(Calib_Std_Timestamp_Start);
    Calib_Std_Timestamp_Start=Calib_Std_Timestamp_Start(:,1:5);
    Calib_Std_Timestamp_End=datevec(Calib_Std_Timestamp_End);
    Calib_Std_Timestamp_End=Calib_Std_Timestamp_End(:,1:5);
end

Ref_Timestamp_Start=datevec(Ref_Timestamp_Start);
Ref_Timestamp_Start=Ref_Timestamp_Start(:,1:5);
Ref_Timestamp_End=datevec(Ref_Timestamp_End);
Ref_Timestamp_End=Ref_Timestamp_End(:,1:5);

Sample_Timestamp=datevec(Sample_Timestamp);

%% Saving the data

%Going to or creating the folder where the working data will be saved
if exist(ResultsFolder,'dir')==0
    mkdir(ResultsFolder)
end

cd(ResultsFolder)

%Constants data
SaveFileName='Constants.txt';

HeaderFormat=['%s',repmat('\t%d',1,size(Wavelengths,2)),'\r\n'];
Header=[{'Wavelengths [nm]'} num2cell(Wavelengths)];

DataFormat=['%s',repmat('\t%f',1,size(Wavelengths,2)),'\r\n'];
Data=[[{'Absorption coefficient water [m-1]'} num2cell(AbsCoeff_Water)];...
      [{'Temperature coefficient [m-1]'} num2cell(TempCoeff)];...
      [{'Salinity coefficient [m-1]'} num2cell(SaltCoeff)]];

fid=fopen(SaveFileName,'w');
fprintf(fid,'%s\r\n',['Radius cavity [m]: ',num2str(r)]);
fprintf(fid,'%s\r\n',['Radius cavity - radius light source [m]: ',num2str(r0)]);
fprintf(fid,'%s\r\n',['Temperature of water absorption coefficient spectrum [�C]: ',num2str(AbsCoeff_WaterT)]);
fprintf(fid,'\r\n');
fprintf(fid,HeaderFormat,Header{1,:});
for i=1:size(Data,1)
    fprintf(fid,DataFormat,Data{i,:});
end
fclose(fid);
clear i ans fid SaveFileName Header HeaderFormat Data DataFormat

%Calibration Value data
SaveFileName='CalibrationData.txt';

HeaderFormat=['%s',repmat('\t%s',1,14),repmat('\t%d',1,size(Wavelengths,2)),'\r\n'];
Header=[{'Calibration No./Name'} {'Label [DO NOT RENAME!]'}...
        {'Year (START)'} {'Month (START)'} {'Day (START)'} {'Hour (START)'} {'Minute (START)'}...
        {'Year (END)'} {'Month (END)'} {'Day (END)'} {'Hour (END)'} {'Minute (END)'}...
        {'Temperature [�C]'} {'N'} {'Units'} num2cell(Wavelengths)];

DataFormat=['%s\t%s',repmat('\t%d',1,10),'\t%.2f\t%.0f\t%s',repmat('\t%f',1,size(Wavelengths,2)),'\r\n'];
Calib_Ref_Data=[Calib_Name repmat({'Calib_Ref'},size(Calib_Name))...
                num2cell(Calib_Ref_Timestamp_Start)...
                num2cell(Calib_Ref_Timestamp_End)...
                num2cell(NaN(size(Calib_Name))) num2cell(Calib_Ref_N) repmat({'[AU]'},size(Calib_Name))...
                num2cell(Calib_Ref_Data)];
Calib_Standard_Data=[Calib_Name repmat({'Calib_Standard'},size(Calib_Name))...
                     num2cell(Calib_Std_Timestamp_Start)...
                     num2cell(Calib_Std_Timestamp_End)...
                     num2cell(NaN(size(Calib_Name))) num2cell(Calib_Standard_N) repmat({'[AU]'},size(Calib_Name))...
                     num2cell(Calib_Standard_Data)];
AbsCoeff_CalStd_Value_Data=[Calib_Name repmat({'AbsCoeff_CalStd_Value'},size(Calib_Name))...
                           num2cell(Calib_Ref_Timestamp_Start)...
                           num2cell(Calib_Std_Timestamp_End)...
                           num2cell(NaN(size(Calib_Name))) num2cell(NaN(size(Calib_Name))) repmat({'[m-1]'},size(Calib_Name))...
                           num2cell(AbsCoeff_CalStd_Value)];
Data=[Calib_Ref_Data;Calib_Standard_Data;AbsCoeff_CalStd_Value_Data];

fid=fopen(SaveFileName,'w');
fprintf(fid,HeaderFormat,Header{1,:});
for i=1:size(Data,1)
    fprintf(fid,DataFormat,Data{i,:});
end
fclose(fid);
clear i fid ans SaveFileName Header HeaderFormat Data DataFormat...
      Calib_Ref_Data Calib_Standard_Data AbsCoeff_Standard_Data

%Calibration Error data
SaveFileName='CalibrationErrors.txt';

HeaderFormat=['%s',repmat('\t%s',1,14),repmat('\t%d',1,size(Wavelengths,2)),'\r\n'];
Header=[{'Calibration No./Name'} {'Label [DO NOT RENAME!]'}...
        {'Year (START)'} {'Month (START)'} {'Day (START)'} {'Hour (START)'} {'Minute (START)'}...
        {'Year (END)'} {'Month (END)'} {'Day (END)'} {'Hour (END)'} {'Minute (END)'}...
        {'Temperature [�C]'} {'N'} {'Units'} num2cell(Wavelengths)];

DataFormat=['%s\t%s',repmat('\t%d',1,10),'\t%.2f\t%.0f\t%s',repmat('\t%f',1,size(Wavelengths,2)),'\r\n'];
Calib_Ref_Data=[Calib_Name repmat({'Calib_Ref'},size(Calib_Name))...
                num2cell(Calib_Ref_Timestamp_Start)...
                num2cell(Calib_Ref_Timestamp_End)...
                num2cell(NaN(size(Calib_Name))) num2cell(Calib_Ref_N) repmat({'[AU]'},size(Calib_Name))...
                num2cell(Calib_Ref_Error)];
Calib_Standard_Data=[Calib_Name repmat({'Calib_Standard'},size(Calib_Name))...
                     num2cell(Calib_Std_Timestamp_Start)...
                     num2cell(Calib_Std_Timestamp_End)...
                     num2cell(NaN(size(Calib_Name))) num2cell(Calib_Standard_N) repmat({'[AU]'},size(Calib_Name))...
                     num2cell(Calib_Standard_Error)];
AbsCoeff_CalStd_Value_Data=[Calib_Name repmat({'AbsCoeff_CalStd_Error'},size(Calib_Name))...
                           num2cell(Calib_Ref_Timestamp_Start)...
                           num2cell(Calib_Std_Timestamp_End)...
                           num2cell(NaN(size(Calib_Name))) num2cell(NaN(size(Calib_Name))) repmat({'[m-1]'},size(Calib_Name))...
                           num2cell(AbsCoeff_CalStd_Error)];
Data=[Calib_Ref_Data;Calib_Standard_Data;AbsCoeff_CalStd_Value_Data];

fid=fopen(SaveFileName,'w');
fprintf(fid,HeaderFormat,Header{1,:});
for i=1:size(Data,1)
    fprintf(fid,DataFormat,Data{i,:});
end
fclose(fid);
clear i fid ans SaveFileName Header HeaderFormat Data DataFormat...
      Calib_Ref_Error Calib_Standard_Error AbsCoeff_Standard_Error

%Reference data
SaveFileName='ReferenceData.txt';

HeaderFormat=['%s',repmat('\t%s',1,13),repmat('\t%d',1,size(Wavelengths,2)),'\r\n'];
Header=[{'Reference No./Name'}...
        {'Year (START)'} {'Month (START)'} {'Day (START)'} {'Hour (START)'} {'Minute (START)'}...
        {'Year (END)'} {'Month (END)'} {'Day (END)'} {'Hour (END)'} {'Minute (END)'}...
        {'Temperature [�C]'} {'N'} {'Units'} num2cell(Wavelengths)];

DataFormat=['%s',repmat('\t%d',1,10),'\t%.2f\t%.0f\t%s',repmat('\t%f',1,size(Wavelengths,2)),'\r\n'];
Data=[Ref_Name...
      num2cell(Ref_Timestamp_Start)...
      num2cell(Ref_Timestamp_End)...
      num2cell(NaN(size(Ref_Name))) num2cell(Ref_N) repmat({'[AU]'},size(Ref_Name)) num2cell(Ref_Data)];

fid=fopen(SaveFileName,'w');
fprintf(fid,HeaderFormat,Header{1,:});
for i=1:size(Data,1)
    fprintf(fid,DataFormat,Data{i,:});
end
fclose(fid);
clear i fid ans SaveFileName Header HeaderFormat Data DataFormat

%Reference error
SaveFileName='ReferenceErrors.txt';

HeaderFormat=['%s',repmat('\t%s',1,13),repmat('\t%d',1,size(Wavelengths,2)),'\r\n'];
Header=[{'Reference No./Name'}...
        {'Year (START)'} {'Month (START)'} {'Day (START)'} {'Hour (START)'} {'Minute (START)'}...
        {'Year (END)'} {'Month (END)'} {'Day (END)'} {'Hour (END)'} {'Minute (END)'}...
        {'Temperature [�C]'} {'N'} {'Units'} num2cell(Wavelengths)];

DataFormat=['%s',repmat('\t%d',1,10),'\t%.2f\t%.0f\t%s',repmat('\t%f',1,size(Wavelengths,2)),'\r\n'];
Data=[Ref_Name...
      num2cell(Ref_Timestamp_Start)...
      num2cell(Ref_Timestamp_End)...
      num2cell(NaN(size(Ref_Name))) num2cell(Ref_N) repmat({'[AU]'},size(Ref_Name)) num2cell(Ref_Error)];
  
fid=fopen(SaveFileName,'w');
fprintf(fid,HeaderFormat,Header{1,:});
for i=1:size(Data,1)
    fprintf(fid,DataFormat,Data{i,:});
end
fclose(fid);
clear i fid ans SaveFileName Header HeaderFormat Data DataFormat
  
%Sample data
SaveFileName='SampleData.txt';

HeaderFormat=['%s',repmat('\t%s',1,9),repmat('\t%d',1,size(Wavelengths,2)),'\r\n'];
Header=[{'Sample No./Name'}...
        {'Year'} {'Month'} {'Day'} {'Hour'} {'Minute'} {'Second'}...
        {'Temperature [�C]'} {'Salinity'} {'Units'} num2cell(Wavelengths)];

DataFormat=['%s',repmat('\t%d',1,6),'\t%.2f\t%.0f\t%s',repmat('\t%f',1,size(Wavelengths,2)),'\r\n'];
Data=[Sample_Name...
      num2cell(Sample_Timestamp)...
      num2cell(NaN(size(Sample_Name))) num2cell(NaN(size(Sample_Name))) repmat({'[AU]'},size(Sample_Name)) num2cell(Sample_Data)];

fid=fopen(SaveFileName,'w');
fprintf(fid,HeaderFormat,Header{1,:});
for i=1:size(Data,1)
    fprintf(fid,DataFormat,Data{i,:});
end
fclose(fid);
clear i ans fid SaveFileName Header HeaderFormat Data DataFormat

cd(BasicPath)

%% End of script

helpdlg({'You can now check or edit the produced text files.',...
         'If available, give temperature and salinity values for',...
         'the different measurements',...
         'They will then be used by the other scripts for data correction'},...
         'Script finished');